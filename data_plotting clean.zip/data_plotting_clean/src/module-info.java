module data_plotting_clean {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.swing;
	requires java.sql;
	requires java.desktop;
	requires transitive javafx.base;
    //exports application.controller;
	opens application to javafx.graphics, javafx.fxml;
}
