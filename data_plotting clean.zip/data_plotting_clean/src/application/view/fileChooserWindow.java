package application.view;

import java.io.File;

import application.Implement_all_controller;
import javafx.stage.FileChooser;

public class fileChooserWindow {
	
	public void _fileChooser() {
		System.out.println("the function has been called");
    	//Stage __stage = (Stage) mainPane.getScene().getWindow();
    	
    	FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select a csv file to plot");  
        
        //open in the default directory
        File initialDirectory = new File("C:/Users/sriva/Desktop/java_stuff/data_plotting/sample_data");
        fileChooser.setInitialDirectory(initialDirectory);
        
        //Only allow CSV files
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("CSV files (*.csv)", "*.csv");
        fileChooser.getExtensionFilters().add(extFilter);
        
        Implement_all_controller.selectedFile = fileChooser.showOpenDialog(null);   
        
        if (Implement_all_controller.selectedFile != null && Implement_all_controller.isItExtraction == false) {
        	System.out.println(Implement_all_controller.selectedFile.getName());
        	System.out.println("filechose---" + Implement_all_controller.fileChosen);
        	Implement_all_controller.filePath = Implement_all_controller.selectedFile.getAbsolutePath();
        	Implement_all_controller.fileChosen.setText("File chosen: "+ Implement_all_controller.selectedFile.getName());
        	Implement_all_controller.dirName.setText("Dir              : "+ Implement_all_controller.selectedFile.getParent());
        	
            System.out.println("Selected file: " + Implement_all_controller.filePath);
            
        } else {
        	//Alert alert = new Alert(Alert.AlertType.WARNING, "No file selected.", ButtonType.OK);
            //alert.show();
            System.out.println("No file selected.-----------");
        }
    }
}
