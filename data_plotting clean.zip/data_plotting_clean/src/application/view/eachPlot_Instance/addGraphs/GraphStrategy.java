package application.view.eachPlot_Instance.addGraphs;
import javafx.scene.layout.AnchorPane;

interface GraphStrategy {
    AnchorPane addGraph();
}

