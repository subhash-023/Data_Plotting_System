package application.view.eachPlot_Instance.addGraphs;

import java.io.IOException;
import java.util.StringJoiner;
import application.Implement_all_controller;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.AnchorPane;
import application.model.parseCsv.ParseCsv;
import application.CONSTANTS;


public class addLineGraph implements GraphStrategy{
	
	@Override
	public AnchorPane addGraph() {
    	
    	NumberAxis xAxis = new NumberAxis();
        NumberAxis yAxis = new NumberAxis();
        //xAxis.setLabel("X Axis");
        //yAxis.setLabel(csvColName.getText());
        
        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle(("Plot from: " + Implement_all_controller.metaPlotDetails.get(String.valueOf(Implement_all_controller.paneCount)).get(0)));
        lineChart.setId("lineChart" + "_tabbedPane_" + Implement_all_controller.paneCount);
        
        XYChart.Series<Number, Number> dataSeries = new XYChart.Series<>();
        dataSeries.setName(Implement_all_controller.csvColName.getText());

        lineChart.getData().add(dataSeries);
        lineChart.setPrefWidth(CONSTANTS.SCREEN_WIDTH-500);
        lineChart.setPrefHeight(450);
        
        AnchorPane chartArea = new AnchorPane();
        AnchorPane.setTopAnchor(lineChart, 6.0);
        AnchorPane.setLeftAnchor(lineChart,3.0); 
        
        StringJoiner joiner = new StringJoiner("_");
        
    	try {
    		
    		
    		ParseCsv p = new ParseCsv();
    		String[] dataToAdd = p.getColumnValues();
    		
    		for (int i = 0; i < dataToAdd.length; i++) {
    			
    			dataSeries.getData().add(new XYChart.Data<>(i, Float.parseFloat(dataToAdd[i]) ));
    			joiner.add(dataToAdd[i]);
            }
    		
    		System.out.println("metaPlotDetails---" + Implement_all_controller.metaPlotDetails +Implement_all_controller.paneCount);
    		String dataAsStringForDb = joiner.toString();
    		
    		System.out.println(Implement_all_controller.metaPlotDetails.get(String.valueOf(Implement_all_controller.paneCount)));
    		Implement_all_controller.metaPlotDetails.get(String.valueOf(Implement_all_controller.paneCount)).add(dataAsStringForDb);
    		
    		for (String value : dataToAdd) {
                System.out.println(value);
            }
    		
        } catch (IOException e) {
            e.printStackTrace();
        }
    	
    	chartArea.getChildren().addAll(lineChart);
    	return chartArea;
    }
	
}
