package application.view.eachPlot_Instance.addGraphs;

import java.io.IOException;
import application.Implement_all_controller;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.AnchorPane;
import application.model.parseCsv.ParseCsv;
import application.CONSTANTS;


public class addBarGraph implements GraphStrategy{
	
	@Override
	public AnchorPane addGraph() {
    	
    	CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        //xAxis.setLabel("X Axis");
        //yAxis.setLabel(csvColName.getText());
        
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle(("Plot from: " + Implement_all_controller.metaPlotDetails.get(String.valueOf(Implement_all_controller.paneCount)).get(0)));
        barChart.setId("barChart" + "_tabbedPane_" + Implement_all_controller.paneCount);
        
        XYChart.Series<String, Number> dataSeries = new XYChart.Series<>();
        dataSeries.setName(Implement_all_controller.csvColName.getText());

        barChart.getData().add(dataSeries);
        barChart.setPrefWidth(CONSTANTS.SCREEN_WIDTH-500);
        barChart.setPrefHeight(450);
        
        AnchorPane chartArea = new AnchorPane();
        AnchorPane.setTopAnchor(barChart, 6.0);
        AnchorPane.setLeftAnchor(barChart,3.0); 
        
    	try {
    		
    		ParseCsv p = new ParseCsv();
    		String[] dataToAdd = p.getColumnValues();
    		
    		for (int i = 0; i < dataToAdd.length; i++) {
    			dataSeries.getData().add(new XYChart.Data<>(String.valueOf(i), Float.parseFloat(dataToAdd[i]) ));
            }
    		/*for (String value : dataToAdd) {
                System.out.println(value);
            }*/
    		
        } catch (IOException e) {
            e.printStackTrace();
        }
    	
    	chartArea.getChildren().addAll(barChart);
    	return chartArea;
    }

}
