package application.view.eachPlot_Instance.addGraphs;

import javafx.scene.layout.AnchorPane;

public class addGraphStrategy {
	
	private GraphStrategy strategy;
	
	public void setStrategy(GraphStrategy strategy) {
        this.strategy = strategy;
    }
	
	public AnchorPane addGraph() {
        return strategy.addGraph();
    }
	
}
