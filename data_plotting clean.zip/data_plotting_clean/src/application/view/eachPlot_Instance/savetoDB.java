package application.view.eachPlot_Instance;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import application.Implement_all_controller;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import application.model.backendSql.Insert_IntoDb;



public class savetoDB implements eachPlot_Instance_ButtonFactory{
	
	@Override
	public Button createComponent() {
    	
        Button savetoDB = new Button();
        savetoDB.setText("Save to database");
        savetoDB.setId("savetoDB" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
        savetoDB.setPrefHeight(30);
        savetoDB.setPrefWidth(150);
    	
    	//event handler for when the button is clicked
        int paneNo = Implement_all_controller.paneCount;
    	savetoDB.setOnAction(event -> {
    		System.out.println("save to db button clicked of: " + savetoDB.getId() + paneNo);
    		
    		Node getDiffElements;
    		
    		//get plot name 
    		getDiffElements =  Implement_all_controller.mainPane.lookup("#plotName" + "_tabbedPane_" + paneNo);
    		TextField pltname = (TextField) getDiffElements;
    		String __plotname = pltname.getText();
    		
    		if (!"".equals(__plotname)) {
    			System.out.println("---pp--" + __plotname);
    			
    			LocalDateTime now = LocalDateTime.now();
	        	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
	        	String __savedAtTime = now.format(formatter);
	        	
	        	//getting the notes/comments section text
        		Node _getNotesNode =  Implement_all_controller.mainPane.lookup("#notes" + "_tabbedPane_" + paneNo);
		    	TextArea _getNotes = (TextArea) _getNotesNode;
    		    String __notes = _getNotes.getText();
    			
    			String __fileName =  Implement_all_controller.metaPlotDetails.get(String.valueOf(paneNo)).get(0);
    			String __dir      =  Implement_all_controller.metaPlotDetails.get(String.valueOf(paneNo)).get(1);
    			String __data     =  Implement_all_controller.metaPlotDetails.get(String.valueOf(paneNo)).get(2);
    			
    			//System.out.println(__fileName);
    			//System.out.println(__dir);
    			//System.out.println(__savedAtTime);
    			//System.out.println(__notes);
    			//System.out.println(__data);
    			
    			//writing to SQLITE 
    			Insert_IntoDb insert = new Insert_IntoDb();
    			insert.query(__plotname, __fileName, __dir, __savedAtTime, __notes, __data);
    			
    		} else {
    			Alert alert = new Alert(Alert.AlertType.WARNING, "Need a plot name to save to db", ButtonType.OK);
                alert.show();
                System.out.println("no plot name given, cannot add");
    		}
    	});
    	
    	return savetoDB;
    }
	

}
