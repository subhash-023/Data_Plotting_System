package application.view.eachPlot_Instance;

import application.Implement_all_controller;
import application.model.backendSql.extractDataForPlot;
import javafx.scene.control.TextArea;

public class makeNotes implements eachPlot_Instance_Factory_TextAreaFactory{
	
	@Override
	public TextArea createComponent() {
    	
    	TextArea makeNotes = new TextArea();
    	makeNotes.setId("notes" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
    	makeNotes.setPromptText("Notes or comments about the graph can be added here.\n It will be saved to the database.");
    	makeNotes.setPrefHeight(300);
    	makeNotes.setPrefWidth(300);
    	
    	if (Implement_all_controller.isItExtraction==true) {
    		extractDataForPlot extract = new extractDataForPlot();
    		//System.out.println(extract.query("notes", Implement_all_controller.sqlRowId));
    		makeNotes.setText((String) extract.query("notes", Implement_all_controller.sqlRowId));
    	}
    	
    	return makeNotes;
    }

}
