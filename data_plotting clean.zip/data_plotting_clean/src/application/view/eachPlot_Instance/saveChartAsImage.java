package application.view.eachPlot_Instance;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.imageio.ImageIO;
import application.CONSTANTS;
import application.Implement_all_controller;
import javafx.animation.PauseTransition;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.Node;
import javafx.scene.SnapshotParameters;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.ScatterChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.WritableImage;
import javafx.util.Duration;

public class saveChartAsImage implements eachPlot_Instance_ButtonFactory{
	
	@Override
	public Button createComponent() {
    	
    	Button saveImg = new Button();
    	saveImg.setText("Save chart as image");
    	saveImg.setId("saveChart" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
    	saveImg.setPrefHeight(30);
    	saveImg.setPrefWidth(200);
    	
    	//event handler for when the button is clicked
    	int paneNo = Implement_all_controller.paneCount;
    	saveImg.setOnAction(event -> {
    		
    		Node node =  Implement_all_controller.mainPane.lookup("#tabbedPane_" + paneNo);
    		
    		//converting from Node to TabPane
    		TabPane getTabPane  = (TabPane) node;
    		
    		SingleSelectionModel<Tab> selectionModel = getTabPane.getSelectionModel();
    		Tab selectedTab = selectionModel.getSelectedItem();
    		
    		if (selectedTab != null) {
    		    String selectedTabName = selectedTab.getText().toLowerCase();  // Get the text of the selected tab
    		    System.out.println("Selected Tab: " + selectedTabName);
    		    
    		    Node _getChart =  Implement_all_controller.mainPane.lookup("#" + selectedTabName + "Chart" + "_tabbedPane_" + paneNo);
    		    
    		    WritableImage image = null;
    		    
        		//converting from Node to different chart types
    		    if ("line".equals(selectedTabName)) {
    		    	LineChart<Number, Number> getChart = (LineChart<Number, Number>) _getChart;
    		    	image = getChart.snapshot(new SnapshotParameters(), null);
    		    } 
    		    else if ("bar".equals(selectedTabName)) {
    		    	BarChart<String, Number> getChart = (BarChart<String, Number>) _getChart;
    		    	image = getChart.snapshot(new SnapshotParameters(), null);
    		    } 
    		    else if ("scatter".equals(selectedTabName)) {
    		    	ScatterChart<Number, Number> getChart = (ScatterChart<Number, Number>) _getChart;
    		    	image = getChart.snapshot(new SnapshotParameters(), null);
    		    } 
    		    else if ("area".equals(selectedTabName)) {
    		    	AreaChart<Number, Number> getChart = (AreaChart<Number, Number>) _getChart;
    		    	image = getChart.snapshot(new SnapshotParameters(), null);
    		    } 

    	        // Convert the image to a BufferedImage
    	        BufferedImage bufferedImage = SwingFXUtils.fromFXImage(image, null);

    	        // Write the image to a file
    	        try {
    	        	
    	        	LocalDateTime now = LocalDateTime.now();
    	        	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    	        	String timestamp = now.format(formatter);
    	        	
    	            File file = new File(CONSTANTS.DOWNLLOAD_DIR+ selectedTabName + "_" + timestamp +  ".png");
    	            ImageIO.write(bufferedImage, "PNG", file);
    	            System.out.println("Chart saved as image: " + file.getAbsolutePath());
    	            
    	            Alert alert = new Alert(AlertType.INFORMATION);
    	            alert.setTitle("Plot saved");
    	            alert.setHeaderText(null);
    	            alert.setContentText("Plot has been saved, it should be in your downloads folder");
    	            alert.show();

    	            // Pause transition for the specified duration
    	            PauseTransition delay = new PauseTransition(Duration.seconds(2));
    	            delay.setOnFinished(z -> alert.close());
    	            delay.play();
    	            
    	            //Desktop.getDesktop().open(file);
    	            
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    		    
    		    System.out.println("Selected Tab: " + selectedTabName);
    		} else {
    		    System.out.println("No tab is currently selected.");
    		}
    	});
    	
    	return saveImg;
    	
    }
}
