package application.view.eachPlot_Instance;

import application.Implement_all_controller;
import javafx.scene.control.TextField;
import application.model.backendSql.extractDataForPlot;


public class plotName implements eachPlot_Instance_Factory_TextFieldFactory{
	
	@Override
	public TextField createComponent() {
    	
    	TextField plotName = new TextField();
    	plotName.setId("plotName" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
    	plotName.setPromptText("Plot name \n(required for saving to db)");
    	plotName.setPrefHeight(30);
    	plotName.setPrefWidth(150);
    	
    	plotName.setStyle("-fx-border-color: green;" +
                          "-fx-border-width: 1px;");
    	
    	if (Implement_all_controller.isItExtraction==true) {
    		extractDataForPlot extract = new extractDataForPlot();
    		plotName.setText((String) extract.query("plotName", Implement_all_controller.sqlRowId));
    	}
    		
    	return plotName;
    }

}
