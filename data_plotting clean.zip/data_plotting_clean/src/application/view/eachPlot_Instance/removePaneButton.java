package application.view.eachPlot_Instance;

import application.CONSTANTS;
import application.Implement_all_controller;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

public class removePaneButton implements eachPlot_Instance_ButtonFactory{
	
	@Override
	public Button createComponent() {
    	
    	Button _rmbt = new Button();
    	_rmbt.setText("remove plot");
    	_rmbt.setId("remove" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
    	_rmbt.setPrefHeight(CONSTANTS.RM_BT_HEIGHT);
    	_rmbt.setPrefWidth(CONSTANTS.RM_BT_WIDTH);
    	
    	//event handler for when the button is clicked
    	int paneNo = Implement_all_controller.paneCount;
    	String containerID_to_remove = "#conatainer_" + paneNo;
    	
    	_rmbt.setOnAction(event -> {
    		
    		Implement_all_controller.metaPlotDetails.remove(String.valueOf(paneNo));
    		
    		AnchorPane torm = (AnchorPane) Implement_all_controller.mainPane.lookup(containerID_to_remove);
    		
    	    ObservableList<Node> __children = Implement_all_controller.mainPane.getChildren();
    	    
    	    int actualStart = 0;
            for (int i = 0; i < __children.size(); i++) {
                if (__children.get(i) == torm) {
                    actualStart = i;
                }
            }
            
            System.out.println("removing pane of index: " + paneNo);
            
            Implement_all_controller.mainPane.getChildren().removeAll(torm);
    	    
    	    for (int i = actualStart; i < Implement_all_controller.mainPane.getChildren().size(); i++) {
    	    	
    	        Node child = Implement_all_controller.mainPane.getChildren().get(i);
    	        
    	        //I guess this (constStartPoint + ((tabHeight + rmBtHeight+20.0)*i)) gives you the bottom y coordinate of the container 
    	        //so we have to *2 to set the top anchor pane 
    	        //but if there are only 2 panes (==3 because of the extra button at the top), then only *1 is enough because 
    	        //because we ....?
    	        //there has to be a better way to write this, I am not sure why this works (?)
    	        //it works for now, so will leave it at that 
    	        
    	        if (i==1 || Implement_all_controller.mainPane.getChildren().size() == 3 )
    	        	AnchorPane.setTopAnchor(child, CONSTANTS.CONST_START_POINT + (CONSTANTS.CONTAINER_HEIGHT*i) - (CONSTANTS.CONTAINER_HEIGHT));
    	        else
    	        	AnchorPane.setTopAnchor(child, CONSTANTS.CONST_START_POINT + (CONSTANTS.CONTAINER_HEIGHT*i) - (CONSTANTS.CONTAINER_HEIGHT*2));
    	        
    	        //System.out.println("current child layout post loop: " + child + ((containerHeight*i) - containerHeight) );
    	        
    	    }
    	    
    	    System.out.println("current y coordinate just before remove: " + Implement_all_controller.currentYCoordinate + "total children: " + Implement_all_controller.mainPane.getChildren().size());
    	    
    	    Implement_all_controller.currentYCoordinate = CONSTANTS.CONST_START_POINT + (CONSTANTS.CONTAINER_HEIGHT * (Implement_all_controller.mainPane.getChildren().size())) - CONSTANTS.CONTAINER_HEIGHT;
    	    
    	    System.out.println("current y coordinate at remove: " + Implement_all_controller.currentYCoordinate);
    	});
    	return _rmbt;
    }
}
