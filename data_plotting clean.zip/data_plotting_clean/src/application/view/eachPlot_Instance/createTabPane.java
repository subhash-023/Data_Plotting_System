package application.view.eachPlot_Instance;

import application.CONSTANTS;
import application.Implement_all_controller;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import application.view.eachPlot_Instance.addGraphs.addGraphStrategy;
import application.view.eachPlot_Instance.addGraphs.addLineGraph;
import application.view.eachPlot_Instance.addGraphs.addBarGraph;
import application.view.eachPlot_Instance.addGraphs.addAreaGraph;
import application.view.eachPlot_Instance.addGraphs.addScatterGraph;


public class createTabPane implements eachPlot_Instance_Factory_TabFactory{
	
	@Override
	public TabPane createComponent() {
    	
    	//create a new tab
        TabPane tabPane = new TabPane();
        
        //set id to access later
        String tabbedPaneID = "tabbedPane_" + Implement_all_controller.paneCount;
        tabPane.setId(tabbedPaneID);
        
        //CSS stuff 
        tabPane.setPrefHeight(CONSTANTS.TAB_HEIGHT);
        tabPane.setPrefWidth(CONSTANTS.SCREEN_WIDTH-490);
        tabPane.setStyle("-fx-padding: " + "3;" 
        				 /*"-fx-border-color: black;"*/);
        
        Tab line = new Tab("Line");
        Tab scatter = new Tab("Scatter");
        Tab bar = new Tab("Bar");
        Tab area = new Tab("Area");
        
        line.setId(tabbedPaneID + "_line");
        scatter.setId(tabbedPaneID + "_scatter");
        bar.setId(tabbedPaneID + "_bar");
        area.setId(tabbedPaneID + "_area");
        
        
        addGraphStrategy addgraphs = new addGraphStrategy();
        
        
        //used strategy pattern here
        addgraphs.setStrategy(new addLineGraph());
        line.setContent(addgraphs.addGraph());
        
        
        addgraphs.setStrategy(new addScatterGraph());
        scatter.setContent(addgraphs.addGraph());
        
        addgraphs.setStrategy(new addBarGraph());
        bar.setContent(addgraphs.addGraph());
        
        addgraphs.setStrategy(new addAreaGraph());
        area.setContent(addgraphs.addGraph());
        
        
        tabPane.getTabs().add(line);
        tabPane.getTabs().add(scatter);
        tabPane.getTabs().add(bar);
        tabPane.getTabs().add(area);
        
        return tabPane;
    }
	
	
	

}
