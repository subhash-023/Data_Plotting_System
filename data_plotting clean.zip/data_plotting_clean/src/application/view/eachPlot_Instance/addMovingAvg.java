package application.view.eachPlot_Instance;

import application.CONSTANTS;
import application.Implement_all_controller;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;

public class addMovingAvg implements eachPlot_Instance_ButtonFactory{
	
	@Override
	public Button createComponent() {
    	
    	Button addMvAvg = new Button();
    	addMvAvg.setText("Add simple moving average");
    	addMvAvg.setId("addMvAvg" + "_tabbedPane_" + Implement_all_controller.paneCount);
    	
    	addMvAvg.setPrefHeight(30);
    	addMvAvg.setPrefWidth(200);
    	
    	//event handler for when the button is clicked
    	int paneNo = Implement_all_controller.paneCount;
    	addMvAvg.setOnAction(event -> {
    		
    		System.out.println("Adding moving avg for: " + addMvAvg.getId());
    		
    		Node node =  Implement_all_controller.mainPane.lookup("#lineChart" + "_tabbedPane_" + paneNo);
    		
    		//converting from Node to LineChart
    		LineChart<Number, Number> getChart = (LineChart<Number, Number>) node;
    		System.out.println(getChart);
    		
    		ObservableList<XYChart.Series<Number, Number>> seriesList = getChart.getData();
    		
    		XYChart.Series<Number, Number> movingAverageSeries = new XYChart.Series<>();
    		movingAverageSeries.setName("Moving Average");
    		
    		XYChart.Series<Number, Number> areaMovingAverageSeries = new XYChart.Series<>();
    		areaMovingAverageSeries.setName("Moving Average");
    		
    		//first loop to iterate through the multiple series if more than 1
    		//second loop iterating through the data 
    		//third loop to calculate the preceding points sum
    		for (XYChart.Series<Number, Number> series : seriesList) {
    			
    			for (int i = (CONSTANTS.MA_PERIOD-1); i < series.getData().size(); i++) {
    		        double sum = 0.0;

    		        for (int j = i-(CONSTANTS.MA_PERIOD-1); j <= i; j++) {
    		            if (j < series.getData().size()) {
    		                sum += series.getData().get(j).getYValue().doubleValue();
    		            }
    		        }
    		        
    		        double movingAverage = sum / CONSTANTS.MA_PERIOD;
    		        //System.out.println("ma---------: " + movingAverage);
    		        
    		        movingAverageSeries.getData().add(new XYChart.Data<>(series.getData().get(i).getXValue(), movingAverage));
    		        areaMovingAverageSeries.getData().add(new XYChart.Data<>(series.getData().get(i).getXValue(), movingAverage));
    		    }
    			//breaking since only one series allowed right now 
    		    break;
    		}
    		
    		getChart.getData().add(movingAverageSeries);
			
    		//adding MA to area chart
	        Node areaNode = Implement_all_controller.mainPane.lookup("#areaChart" + "_tabbedPane_" + Implement_all_controller.paneCount);
	        AreaChart<Number, Number> getAreaChart = (AreaChart<Number, Number>) areaNode;
	        getAreaChart.getData().add(areaMovingAverageSeries);
	        
    	});
    	
    	return addMvAvg;
    }
}
