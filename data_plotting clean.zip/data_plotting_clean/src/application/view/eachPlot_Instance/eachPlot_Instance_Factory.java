package application.view.eachPlot_Instance;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

interface  eachPlot_Instance_ButtonFactory {
	Button createComponent();
}

interface  eachPlot_Instance_Factory_TabFactory {
	TabPane createComponent();
}

interface  eachPlot_Instance_Factory_TextAreaFactory {
	TextArea createComponent();
}

interface  eachPlot_Instance_Factory_TextFieldFactory {
	TextField createComponent();
}

