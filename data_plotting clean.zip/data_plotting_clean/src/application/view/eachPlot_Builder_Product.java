package application.view;

import application.CONSTANTS;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class eachPlot_Builder_Product {
	
	private TabPane    _tabPane;  
    private TextField  _plotNameArea;   
    private Button     _reomvePaneBt;
    private Button     _savetodDBbt; 
    private Button     _addMovingAvgBt; 
    private Button     _saveImgBt;
    private TextArea   _makeNotesArea;
	public AnchorPane _container;
	
	public eachPlot_Builder_Product(eachPlot_Builder builder) {
		
        this._tabPane         = builder._tabPane;
        this._plotNameArea    = builder._plotNameArea;
        this._reomvePaneBt    = builder._reomvePaneBt;
        this._savetodDBbt     = builder._savetodDBbt;
        this._addMovingAvgBt  = builder._addMovingAvgBt;
        this._saveImgBt       = builder._saveImgBt;
        this._makeNotesArea   = builder._makeNotesArea;
        this._saveImgBt       = builder._saveImgBt;
        this._container       = builder._container;
    }
	
	//builder 
	public static class eachPlot_Builder {
		
		protected TabPane    _tabPane;  
		protected TextField  _plotNameArea;   
	    protected Button     _reomvePaneBt;
	    protected Button     _savetodDBbt; 
	    protected Button     _addMovingAvgBt; 
	    protected Button     _saveImgBt;
	    protected TextArea   _makeNotesArea;
	    protected AnchorPane _container;
	    
	    
	    public eachPlot_Builder set_plotNameArea (double x, double y) {
	    	
	    	this._plotNameArea = eachPlot_FactoryManager.createTextFieldComponent("PlotName");
	    	AnchorPane.setTopAnchor(this._plotNameArea,  x); //3.0
	        AnchorPane.setLeftAnchor(this._plotNameArea, y); //6.0
	    	
	    	return this;
	    }
	    
	    public eachPlot_Builder set_reomvePaneBt (double x, double y) {
	    	
	    	this._reomvePaneBt = eachPlot_FactoryManager.createButtonComponent("RemovePaneButton");
	    	AnchorPane.setTopAnchor(this._reomvePaneBt,  x); //160.0
	        AnchorPane.setLeftAnchor(this._reomvePaneBt, y); //6.0
	        
	        return this;
	        
	    }
	    
	    public eachPlot_Builder set_savetodDBbt (double x, double y) {
	    	
	    	this._savetodDBbt = eachPlot_FactoryManager.createButtonComponent("SaveToDatabase");
	    	AnchorPane.setTopAnchor(this._savetodDBbt,  x); //267.0
	        AnchorPane.setLeftAnchor(this._savetodDBbt, y); //6.0
	        
	        return this;
	    	
	    }
	    
	    public eachPlot_Builder set_addMovingAvgBt (double x, double y) {
	    	
	    	this._addMovingAvgBt = eachPlot_FactoryManager.createButtonComponent("MovingAvgButton");
	    	AnchorPane.setTopAnchor(this._addMovingAvgBt,  x); //425.0
	        AnchorPane.setLeftAnchor(this._addMovingAvgBt, y); //6.0
	        
	        return this;
	    	
	    }
	    
	    public eachPlot_Builder set_saveImgBt (double x, double y) {
	    	
	    	this._saveImgBt = eachPlot_FactoryManager.createButtonComponent("SaveChartAsImage");
	    	AnchorPane.setTopAnchor(this._saveImgBt,  x); //630.0
	        AnchorPane.setLeftAnchor(this._saveImgBt, y); //6.0
	        
	        return this;
	        
	    }
	    
	    public eachPlot_Builder set_makeNotesArea (double y) {
	    	
	    	this._makeNotesArea = eachPlot_FactoryManager.createTextAreaComponent("TextAreaForNotes");
	    	AnchorPane.setTopAnchor(this._makeNotesArea,  y); //40.0
	        AnchorPane.setLeftAnchor(this._makeNotesArea, CONSTANTS.SCREEN_WIDTH-480); 
	        
	        return this;
	        
	    }
	    
	    public eachPlot_Builder set_tabPane () {
	    	
	    	this._tabPane = eachPlot_FactoryManager.createTabPaneComponent("CreateTabPane");
	    	AnchorPane.setTopAnchor(this._tabPane,  5.0+2.0+CONSTANTS.RM_BT_HEIGHT);  //2.0 acts like padding, better to put this in CSS
	        
	        return this;
	        
	    }
	    
	    public eachPlot_Builder set_container (String bgcolor) {
	    	
	    	System.out.println("indide set container------" + this._plotNameArea);
	    	
	    	this._container = new AnchorPane();
	    	
	    	this._container.getChildren().addAll(this._plotNameArea, 
	    										 this._reomvePaneBt,
	    										 this._savetodDBbt,
	    										 this._addMovingAvgBt, 
	    										 this._saveImgBt, 
	    										 this._tabPane, 
	    										 this._makeNotesArea);
	    	
	    	this._container.setStyle("-fx-border-color: black;" +
	    			                 "-fx-border-width: 2px;"   +
	    			                 "-fx-background-color: " + bgcolor + ";" +
					                 "-fx-padding:      3;");
	    	
	    	this._container.setPrefWidth(CONSTANTS.SCREEN_WIDTH-5);
	    	
	    	return this;
	    	
	    }
	    
	    public eachPlot_Builder_Product build () {
	    	
	    	return new eachPlot_Builder_Product (this);
	    	
	    }

	}
	
}
