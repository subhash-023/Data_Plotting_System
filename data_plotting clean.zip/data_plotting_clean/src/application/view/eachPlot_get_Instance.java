package application.view;

public class eachPlot_get_Instance {
	
	//implement BORG here?
	
	public static eachPlot_Builder_Product _getInstance () {
		
		eachPlot_Builder_Product _get = new eachPlot_Builder_Product.eachPlot_Builder()
										.set_plotNameArea(6.0, 3.0)
										.set_reomvePaneBt(6.0, 160.0)
										.set_savetodDBbt(6.0, 267.0)
										.set_addMovingAvgBt(6.0, 425.0)
										.set_saveImgBt(6.0, 630.0)
										.set_makeNotesArea(40.0)
										.set_tabPane()
										.set_container("#FAF9F6")
									    .build();
		
		return _get;
	}
}
