package application.view;

import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import application.view.eachPlot_Instance.addMovingAvg;
import application.view.eachPlot_Instance.createTabPane;
import application.view.eachPlot_Instance.makeNotes;
import application.view.eachPlot_Instance.plotName;
import application.view.eachPlot_Instance.removePaneButton;
import application.view.eachPlot_Instance.saveChartAsImage;
import application.view.eachPlot_Instance.savetoDB;

public class eachPlot_FactoryManager {
	
	public static Button createButtonComponent(String type) {
        if ("MovingAvgButton".equals(type)) {
            return new addMovingAvg().createComponent();
            
        } else if ("RemovePaneButton".equals(type)) {
            return new removePaneButton().createComponent();
            
        } else if ("SaveChartAsImage".equals(type)) {
            return new saveChartAsImage().createComponent();
            
        } else if ("SaveToDatabase".equals(type)) {
            return new savetoDB().createComponent();
        }
        
        return null;
    }
	
	public static TabPane createTabPaneComponent(String type) {
        if ("CreateTabPane".equals(type)) {
            return new createTabPane().createComponent();
        }    
        return null;
    }
	
	public static TextArea createTextAreaComponent(String type) {
        if ("TextAreaForNotes".equals(type)) {
            return new makeNotes().createComponent();
        }
        return null;
    }
	
	public static TextField createTextFieldComponent(String type) {
        if ("PlotName".equals(type)) {
            return new plotName().createComponent();
        }
        return null;
    }
	
	
}
