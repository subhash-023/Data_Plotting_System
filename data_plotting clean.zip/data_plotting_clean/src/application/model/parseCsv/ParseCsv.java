package application.model.parseCsv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import application.CONSTANTS;
import application.Implement_all_controller;
import application.model.backendSql.extractDataForPlot;


public class ParseCsv {
	
	
	public String[] getColumnValues() throws IOException {
    	
    	List<String> columnValues;
    	
    	if (Implement_all_controller.isItExtraction==true) {
    		
    		extractDataForPlot extract = new extractDataForPlot();
    		
    		String datatoPlotfromDB = (String) extract.query("data", Implement_all_controller.sqlRowId);
    		String[] dataArray = datatoPlotfromDB.split("_");
    		columnValues = Arrays.asList(dataArray);
    		
    		//System.out.println("parsing!!!!!!!!!!!!!!!" + columnValues.toArray(new String[0]));
    		
    		return columnValues.toArray(new String[0]);
    	}
    	else {	
	    	columnValues = new ArrayList<>();
	        int columnIndex = -1;
	        
	        try (BufferedReader reader = new BufferedReader(new FileReader(Implement_all_controller.filePath))) {
	            String headerLine = reader.readLine();
	            String[] headers = headerLine.split(CONSTANTS.DELIMITER);
	            columnIndex = Arrays.asList(headers).indexOf(Implement_all_controller.csvColName.getText());
	
	            if (columnIndex == -1) {
	            	
	            	String alertText = "Column name '" + Implement_all_controller.csvColName.getText() + "' not found in the CSV file.";
	            	Alert alert = new Alert(Alert.AlertType.WARNING, alertText, ButtonType.OK);
	                alert.show();
	                throw new IllegalArgumentException();
	                
	            }
	
	            String line;
	            while ((line = reader.readLine()) != null) {
	                String[] columns = line.split(CONSTANTS.DELIMITER);
	                if (columnIndex >= 0 && columnIndex < columns.length) {
	                	
	                	String flyweight = parseFlyweight.getFlyweight(columns[columnIndex]);
	                    columnValues.add(flyweight);
	                    //columnValues.add(columns[columnIndex]);
	                }
	            }
	        }
	        //System.out.println("parsing!!!!!!!!!!!!!!!" + columnValues.toArray(new String[0]));
	        return columnValues.toArray(new String[0]);
    	}
    }
	

}
