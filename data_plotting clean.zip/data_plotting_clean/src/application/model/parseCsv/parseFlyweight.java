package application.model.parseCsv;

import java.util.HashMap;
import java.util.Map;


public class parseFlyweight {
	
	private static final Map<String, String> flyweights = new HashMap<>();

    public static String getFlyweight(String value) {
    	
        if (!flyweights.containsKey(value)) {
        
        	System.out.println("creating new flyweight since does not exist: " + value);
            flyweights.put(value, value);
        
        } else {
        	System.out.println("Value already exists, getting from previous flyweight: " + value);
        }
        
        return flyweights.get(value);
    }

}
