package application.model.backendSql;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Remove_FromDb extends Sql_Template {
	
	@SuppressWarnings("unchecked")
	@Override
	protected <T> T executeQuery(T... items) {
		
		int _id = (int) items[0];
		
		query = "DELETE FROM plotData WHERE id = ?";
		
		try {
			
			PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, _id);
            pstmt.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("Error deleting row: " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("Instance with id: " + _id + "sucessfully removed from db");
		return (T) "Removed from DB";
		
	}
}
