package application.model.backendSql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import application.CONSTANTS;

public class CreateDB {
	
	private static final String CREATE_TABLE_SQL = """
    		
    		CREATE TABLE IF NOT EXISTS plotData (
    			
    			id INTEGER PRIMARY KEY,
    			
    			plotName     TEXT,
    			fileName     TEXT,
    			dir          TEXT,
    			savedAtTime  TEXT,
    			
    			notes        BLOB,
    			data         BLOB
    			
    		)""";
	
	
	public static void main(String[] args) {
        try {
        	
            Connection connection = DriverManager.getConnection(CONSTANTS.JDBC_URL);
 
            Statement statement = connection.createStatement();

            statement.execute(CREATE_TABLE_SQL);

            statement.close();
            connection.close();

            System.out.println("Database with table 'plotData' created at: " + CONSTANTS.JDBC_URL);
            
        } catch (SQLException e) {
            System.err.println("Error creating sample table: " + e.getMessage());
        }
    }
	
}
