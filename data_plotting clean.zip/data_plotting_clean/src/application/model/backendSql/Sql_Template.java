package application.model.backendSql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import application.CONSTANTS;


@SuppressWarnings("unchecked")
abstract class Sql_Template {
	
	public String query;
	public String result;
	public Connection conn;
	
	public final <T> T query (T... items) {
		
		getConnection();
		T result = executeQuery(items);
		closeConnection();
		
		return result;
		
	}
	
	protected abstract <T> T executeQuery(T... items);
	
	private void getConnection() {
		
		try {
			System.out.println("Connecting to database");
			
			conn = DriverManager.getConnection(CONSTANTS.JDBC_URL);
			
			System.out.println("Connected successfully to database");
			
		} catch (SQLException e) {
			System.out.println("Could not connect to database");
			e.printStackTrace();
		}
		
	}
	
	private void closeConnection() {
		
		/*try {
			//conn.close();
			System.out.println("Database connection closed");
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
	}

}
