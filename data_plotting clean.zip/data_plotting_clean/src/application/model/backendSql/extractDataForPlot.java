package application.model.backendSql;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class extractDataForPlot extends Sql_Template {
	
	@SuppressWarnings("unchecked")
	@Override
	protected <T> T executeQuery(T... items) {
		
		String col = (String) items[0];
		int _id = (int) items[1];
		
		result = null;
		query = "SELECT " + col + " FROM plotData WHERE id = ?";
		
		try {
			
			PreparedStatement pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, _id);
	         
			ResultSet rs = pstmt.executeQuery();
			result = rs.getString(col);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return (T) result;
		
	}

}
