package application.model.backendSql;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javafx.animation.PauseTransition;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Duration;



public class Insert_IntoDb extends Sql_Template{
	
	@SuppressWarnings("unchecked")
	@Override
	protected <T> T executeQuery(T... items) {
		
		result = null;
		query = "INSERT INTO plotData (plotName, fileName, dir, savedAtTime, notes, data) VALUES (?, ?, ?, ?, ?, ?)";
		
		try {
		
			PreparedStatement preparedStatement = conn.prepareStatement(query);
			
			int index = 0;
			
			for (T item: items) {
				index++;
				
				String col = (String) item;
				preparedStatement.setString(index, col);
				
			}
			
			preparedStatement.executeUpdate();
		    System.out.println("Saved to db successfully");
		    
		    preparedStatement.close();
		    //conn.commit();
				
			Alert alert = new Alert(AlertType.INFORMATION);
	        alert.setTitle("Plot saved");
	        alert.setHeaderText(null);
	        alert.setContentText("Plot has been saved in the database");
	        alert.show();
	
	        PauseTransition delay = new PauseTransition(Duration.seconds(1.5));
	        delay.setOnFinished(z -> alert.close());
	        delay.play();	
	        
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return (T) "Inserted";
		
	}

}
