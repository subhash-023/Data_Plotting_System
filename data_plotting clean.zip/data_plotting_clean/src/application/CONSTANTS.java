package application;

import javafx.stage.Screen;

public class CONSTANTS {
	
	public static final String JDBC_URL = "jdbc:sqlite:C:/Users/sriva/Desktop/java_stuff/mainDatabase.db";
	
	public static final String DELIMITER= ",";
	
	public static final double SCREEN_WIDTH = Screen.getPrimary().getVisualBounds().getWidth();
	
	public static final int TAB_HEIGHT = 500;
	
	public static final int RM_BT_HEIGHT = 30;
	public static final int RM_BT_WIDTH =  100;
	
	public static final double CONTAINER_HEIGHT = (TAB_HEIGHT + RM_BT_HEIGHT + 20.0);
	
	public static final double CONST_START_POINT = 150;
	
	public static final int MA_PERIOD = 3;
	
	public static final String DOWNLLOAD_DIR= "C:/Users/sriva/Downloads/";
	
}
