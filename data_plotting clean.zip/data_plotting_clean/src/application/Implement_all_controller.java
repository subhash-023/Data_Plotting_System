package application;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import application.view.fileChooserWindow;
import application.model.backendSql.extractDataForPlot;
import application.view.eachPlot_get_Instance;
import application.view.eachPlot_Builder_Product;
import application.model.backendSql.extractEntire_instance;
import application.model.backendSql.Remove_FromDb;



public class Implement_all_controller extends Application {
	
	
	public static AnchorPane mainPane;
    public static Label fileChosen, dirName;
	public static TextField csvColName = null;
	
	public static Map<String, List<String>> metaPlotDetails = new HashMap<>();
	public static int paneCount = 0;
	public static double currentYCoordinate = 150;
	public static String filePath = null;
	public static File selectedFile = null;
	public static boolean isItExtraction = false;
	public static int sqlRowId = -1;
	
    
	@Override
    public void start(Stage primaryStage) throws Exception {
		
		AnchorPane initalstuff = new AnchorPane();
		initalstuff.getChildren().addAll(initialStuff());
		
		mainPane = initalstuff;
		
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);  
        scrollPane.setFitToHeight(true);
        scrollPane.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
        scrollPane.setMinHeight(600);
        scrollPane.setContent(mainPane);
        
        primaryStage.setTitle("Plot It");
        primaryStage.setScene(new Scene(scrollPane, 900, 400));
        primaryStage.show();
        
    }
	
	private AnchorPane initialStuff() {
		
		AnchorPane  _initialStuff = new AnchorPane ();
		
		// add plot button
		Button addPlotButton = new Button("Add plot");
		AnchorPane.setTopAnchor(addPlotButton, 93.0 );
        AnchorPane.setLeftAnchor(addPlotButton, 11.0);
        addPlotButton.setOnAction(event -> addTabs());
        
        // choose file button
        Button chooseFileButton = new Button("Choose File");
        AnchorPane.setTopAnchor(chooseFileButton, 27.0 );
        AnchorPane.setLeftAnchor(chooseFileButton, 11.0);
        chooseFileButton.setOnAction(event -> fileChooser());
        
        //extract from database button
        Button extractButton = new Button("Extract from saved plots");
        AnchorPane.setTopAnchor(extractButton, 93.0);
        AnchorPane.setLeftAnchor(extractButton, 87.0);
        extractButton.setOnAction(event -> extractFromDb());
        
        // file name label
        fileChosen = new Label("File name: ");
        AnchorPane.setTopAnchor(fileChosen, 18.0);
        AnchorPane.setLeftAnchor(fileChosen, 102.0);
        
        // DIR name label
        dirName = new Label("Directory: ");
        AnchorPane.setTopAnchor(dirName, 31.0 );
        AnchorPane.setLeftAnchor(dirName, 102.0);
        
        // column name in CSV file TextField
        csvColName = new TextField();
        AnchorPane.setTopAnchor(csvColName, 58.0);
        AnchorPane.setLeftAnchor(csvColName, 11.0);
        csvColName.setPromptText("Enter column name of CSV to plot");
		
        _initialStuff.getChildren().addAll(addPlotButton, chooseFileButton, extractButton, fileChosen, dirName, csvColName);
        
        return _initialStuff;
	}
	
	
	public static void main(String[] args) {
        launch(args);
    }
	
	
	//---------------------------------------------------------
	
	//Can't really implement this in model since we need access to addTabs() 
	//which will then have to be declare static and then we will end up loosing access to everything else?
	//best workaround is to make move the code within addTabs() to another class and then call I guess?
	private void extractFromDb() {
		
		Stage newStage = new Stage();
        AnchorPane secondaryLayout = new AnchorPane();
        Scene secondScene = new Scene(secondaryLayout, 800, 200);
        newStage.setTitle("Extract from db");
        newStage.setScene(secondScene);
        newStage.show();
		
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(5);
        
        //extract the entire instance from database 
        extractEntire_instance _inst = new extractEntire_instance();
        ResultSet rs = (ResultSet) _inst.query();
        
    	int colIndex = 1;
    	
    	//adding headers
    	//all columns list = "id", "plotName", "fileName", "dir", "savedAtTime", "notes", "data"
    	for (String value : Arrays.asList("plotName", "fileName", "dir", "savedAtTime")) { 
        	
    		Button _header = new Button();
    		_header.setText(value);
    		_header.setPrefHeight(20);
    		_header.setPrefWidth(150);
        	gridPane.add(_header, colIndex, 0);
        	
        	colIndex++;
        }
    	
    	//starting from 1 because used 0 for headers above
    	int rowIndex = 1;
    	
    	try {
    	
	        while (rs.next()) {
	        	
	        	int _rowIdxfor_rm = rowIndex;
	        	int _id = rs.getInt("id");
	        	
	        	Button _extractBt = new Button();
	        	_extractBt.setText("Extract this from db");
	        	_extractBt.setId("id_from_db_" + rowIndex);
	        	_extractBt.setPrefHeight(7.5);
	        	_extractBt.setPrefWidth(150);
	        	
	        	_extractBt.setOnAction(t -> addExtractedFromDb(_id) );
	        	
	        	Button _removeBt = new Button();
	        	_removeBt.setText("Remove from db");
	        	_removeBt.setId("remove_id_from_db_" + rowIndex);
	        	_removeBt.setPrefHeight(7.5);
	        	_removeBt.setPrefWidth(150);
	        	
	        	//event listener for 
	        	_removeBt.setOnAction(t -> {
	        		
	        		ObservableList<Node> children = gridPane.getChildren();
	        		children.removeIf(node -> GridPane.getRowIndex(node) == _rowIdxfor_rm);
	        		
	        		Remove_FromDb _remove = new Remove_FromDb();
	        		_remove.query(_id);
	        	});
	        	
	        	VBox buttonBox = new VBox(_extractBt, _removeBt);
	        	
	        	gridPane.add(buttonBox, 0, rowIndex);
	        	
	        	//starting from 1 since used 0 for the button
	        	colIndex = 1;
	            
	            for (String value : Arrays.asList("plotName", "fileName", "dir", "savedAtTime")) { 
	            	
	            	TextArea _addCell = new TextArea(rs.getString(value));
	            	_addCell.setPrefHeight(20);
	            	_addCell.setPrefWidth(150);
	            	
	            	gridPane.add(_addCell, colIndex, rowIndex);
	            	
	            	colIndex++;
	            	
	            }
	            rowIndex++;
	        }
	        
    	} catch (SQLException e) {
			e.printStackTrace();
		}
    
        secondaryLayout.getChildren().add(gridPane);
    	
    }
	
	
	private void addExtractedFromDb(int _id) {
		
		isItExtraction = true;
		sqlRowId = _id;
		System.out.println("extractFromDb is True");
		
		addTabs();
		
	}
	
	
    public void addTabs() {
    	
    	if ((isItExtraction==true) || (filePath != null && csvColName != null)) {
    		
    		
    		paneCount += 1;
    		
    		//adding stuff to metaPlotDetails 
    		List<String> initialList = new ArrayList<>();
    		if (isItExtraction){
    			extractDataForPlot extract = new extractDataForPlot();
    			
    			initialList.add((String) extract.query("fileName", sqlRowId));
        		initialList.add((String) extract.query("dir", sqlRowId));
        		metaPlotDetails.put(String.valueOf(paneCount), initialList);
    			
    		} else {
    			initialList.add(selectedFile.getName());
        		initialList.add(selectedFile.getParent());
        		metaPlotDetails.put(String.valueOf(paneCount), initialList);
    		}
	        
	        AnchorPane  _container = new AnchorPane ();
	        
	        eachPlot_Builder_Product _new =  eachPlot_get_Instance._getInstance();
	        
	        _container = _new._container;
	        
	        String containerID = "conatainer_" + paneCount;
	        _container.setId(containerID);
	        
	        AnchorPane.setTopAnchor(_container, currentYCoordinate);
	        
	        mainPane.getChildren().addAll(_container);
	        
	        currentYCoordinate += CONSTANTS.CONTAINER_HEIGHT;
	        System.out.println("current y coordinate at add: " + currentYCoordinate);
	        
	        System.out.println("children in main pane-------- " + mainPane.getChildren());
	        System.out.println(metaPlotDetails);
	        
	        isItExtraction = false;
	        
	        
    	} else {
    		Alert alert = new Alert(Alert.AlertType.WARNING, "No file selected.", ButtonType.OK);
            alert.show();
            System.out.println("No file selected.");
    	}
        
    }

    
    private void fileChooser() {
    	
    	System.out.println("filechosen----: " + Implement_all_controller.fileChosen);
    	fileChooserWindow f = new fileChooserWindow();
    	f._fileChooser();
    	
    }
    
}
